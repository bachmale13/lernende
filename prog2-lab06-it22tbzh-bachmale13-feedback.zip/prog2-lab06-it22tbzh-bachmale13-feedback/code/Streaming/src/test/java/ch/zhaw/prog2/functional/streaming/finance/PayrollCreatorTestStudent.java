package ch.zhaw.prog2.functional.streaming.finance;


/**
 * This test class is for all test methods written by students for easier review by lecturers.
 * In a real application these test would be in the class PayrollCreatorTest.
 * 
 * ✅  This class should be worked on by students. 
 */
public class PayrollCreatorTestStudent {

}
